package com.p.p

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.*
import androidx.savedstate.*
import com.p.p.ui.EditorWindowUI
import com.p.p.ui.FloatWindowUI
import com.p.p.ui.MenuWindowUI

class AutoService : AccessibilityService() {

    companion object {
        var instance: AutoService? = null
    }

    private lateinit var windowManager: WindowManager
    private lateinit var sp: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var floatView: ComposeView? = null
    private var menuView: ComposeView? = null
    private var editorView: ComposeView? = null
    private var floatParams: WindowManager.LayoutParams? = null

    var isRunning by mutableStateOf(false)
    var isWindowAdded = false
    private var isMenuAdded = false
    private var isEditorAdded = false
    
    private var lastMenuCloseTime = 0L 


    var scanChecked by mutableStateOf(false)
    var checkChecked by mutableStateOf(false)
    var ctrlChecked by mutableStateOf(false)
    var okChecked by mutableStateOf(false)
    var nextChecked by mutableStateOf(false)
    
    var remainingMinutes by mutableStateOf(0L)

    private var isShowTouch = false
    private var isScreenOn = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var nextActionTime: Long = 0
    private var startTime: Long = 0
    private var maxRunTimeMillis: Long = 3600000

    private var screenWidth = 0
    private var screenHeight = 0
    private val previewViews = mutableMapOf<String, View>()

    private var currentEditKey: String = ""
    private var tempL = 0f
    private var tempT = 0f
    private var tempW = 0f
    private var tempH = 0f

    private var floatLifecycleOwner: ServiceLifecycleOwner? = null
    private var menuLifecycleOwner: ServiceLifecycleOwner? = null
    private var editorLifecycleOwner: ServiceLifecycleOwner? = null

        private val taskRunnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                // 1. 处理最大运行时间倒计时
                if (maxRunTimeMillis > 0) {
                    val elapsed = System.currentTimeMillis() - startTime
                    if (elapsed >= maxRunTimeMillis) {
                        setRunningState(false)
                        showCustomToast("已达到最大运行时间，自动停止")
                        // 【修复】：去掉了原版这里的 return，防止整个循环死掉
                    } else {
                        remainingMinutes = (maxRunTimeMillis - elapsed + 59999) / 60000
                    }
                }
                
                // 2. 如果时间没到（依然在 running），就去执行找按钮和点击的逻辑
                if (isRunning && System.currentTimeMillis() >= nextActionTime) {
                    performSmartLogic()
                }
            }
            
            // 【修改】：轮询时间从 50 改为 300，兼顾反应速度和系统性能
            handler.postDelayed(this, 300)
        }
    }


    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        sp = getSharedPreferences("auto_config", Context.MODE_PRIVATE)
        isShowTouch = sp.getBoolean("show_touch", true)
        isScreenOn = sp.getBoolean("screen_on", true)
        applyScreenOn()
        updateMaxTime()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        updateScreenSize()
        
        val info = AccessibilityServiceInfo()
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        serviceInfo = info
        
        showCustomToast("危化杀手已就绪")
        handler.post(taskRunnable)
    }

    fun updateMaxTime() {
        val mins = sp.getInt("max_time", 60)
        maxRunTimeMillis = if (mins <= 0) 0 else mins * 60 * 1000L
    }

    private fun updateScreenSize() {
        val point = Point()
        windowManager.defaultDisplay.getRealSize(point)
        screenWidth = point.x
        screenHeight = point.y
    }

    fun toggleWindow() {
        if (isWindowAdded) removeFloatView() else showFloatView()
    }

    private fun showFloatView() {
        if (isWindowAdded) return
        floatParams = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }

        floatLifecycleOwner = ServiceLifecycleOwner().apply { attach() }

        floatView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            floatLifecycleOwner?.injectInto(this)
            setContent {
                // 【修改1】展开时只显示"开始"或"暂停"
                val btnText = if (isRunning) "暂停" else "开始"
                // 【修改2】给小圆球专属显示的剩余时间
                val remainText = if (maxRunTimeMillis > 0) "${remainingMinutes}分" else "运行"
                
                FloatWindowUI(
                    onCloseClick = { toggleWindow() },
                    onMenuClick = { toggleMenu() },
                    onActionClick = { setRunningState(!isRunning) },
                    onDrag = { dx, dy ->
                        floatParams!!.x += dx.toInt()
                        floatParams!!.y += dy.toInt()
                        windowManager.updateViewLayout(floatView, floatParams)
                        updateMenuPosition()
                    },
                    actionText = btnText,
                    remainText = remainText, // 传入小圆球文字
                    isRunning = isRunning
                )
            }

        }
        windowManager.addView(floatView, floatParams)
        isWindowAdded = true
    }

    private fun removeFloatView() {
        if (floatView != null && isWindowAdded) {
            windowManager.removeView(floatView)
            floatLifecycleOwner?.destroy()
            isWindowAdded = false
            setRunningState(false)
            removeMenu()
            previewViews.values.forEach { try { windowManager.removeView(it) } catch (e: Exception) {} }
            previewViews.clear()
        }
    }

    private fun toggleMenu() {
        if (isMenuAdded) {
            removeMenu()
        } else {
            if (System.currentTimeMillis() - lastMenuCloseTime > 200) {
                showMenu()
            }
        }
    }

    private fun removeMenu() {
        if (menuView != null && isMenuAdded) {
            windowManager.removeView(menuView)
            menuLifecycleOwner?.destroy()
            isMenuAdded = false
            lastMenuCloseTime = System.currentTimeMillis() 
        }
    }


    private fun showMenu() {
        val p = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.START
            x = floatParams!!.x
            y = floatParams!!.y + 100
        }

        syncMenuCheckStates()
        menuLifecycleOwner = ServiceLifecycleOwner().apply { attach() }

        menuView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            menuLifecycleOwner?.injectInto(this)
            
            setOnTouchListener { _, event ->
                if (event.action == android.view.MotionEvent.ACTION_OUTSIDE) {
                    removeMenu()
                    return@setOnTouchListener true
                }
                false
            }

            setContent {
                MenuWindowUI(
                    onCloseClick = { toggleMenu() },
                    scanChecked = scanChecked, onScanChange = { scanChecked = it; handleCheck("scan", it, "执行中") }, onScanEdit = { startEditing("scan", "执行中") },
                    checkChecked = checkChecked, onCheckChange = { checkChecked = it; handleCheck("check", it, "未检查") }, onCheckEdit = { startEditing("check", "未检查") },
                    ctrlChecked = ctrlChecked, onCtrlChange = { ctrlChecked = it; handleCheck("ctrl", it, "受控") }, onCtrlEdit = { startEditing("ctrl", "受控") },
                    nextChecked = nextChecked, onNextChange = { nextChecked = it; handleCheck("next", it, "下一个") }, onNextEdit = { startEditing("next", "下一个") }
                )
            }
        }
        windowManager.addView(menuView, p)
        isMenuAdded = true
    }

    
    private fun syncMenuCheckStates() {
        scanChecked = previewViews.containsKey("scan")
        checkChecked = previewViews.containsKey("check")
        ctrlChecked = previewViews.containsKey("ctrl")
        okChecked = previewViews.containsKey("ok")
        nextChecked = previewViews.containsKey("next")
    }


    private fun handleCheck(key: String, isChecked: Boolean, title: String) {
        if (isChecked) {
            if (sp.getFloat("${key}_w", 0f) == 0f) {
                showCustomToast("请先点击【编辑 ✏️】设置区域！")
                when(key) {
                    "scan" -> scanChecked = false
                    "check" -> checkChecked = false
                    "ctrl" -> ctrlChecked = false
                    "ok" -> okChecked = false
                    "next" -> nextChecked = false
                }
            } else {
                val l = sp.getFloat("${key}_l", 0f)
                val t = sp.getFloat("${key}_t", 0f)
                val w = sp.getFloat("${key}_w", 0f)
                val h = sp.getFloat("${key}_h", 0f)
                showPreview(key, l, t, w, h)
            }
        } else {
            hidePreview(key)
        }
    }


    
    

    private fun updateMenuPosition() {
        if (menuView != null && isMenuAdded) {
            val p = menuView!!.layoutParams as WindowManager.LayoutParams
            p.x = floatParams!!.x
            p.y = floatParams!!.y + 100
            windowManager.updateViewLayout(menuView, p)
        }
    }

    fun startEditing(key: String, title: String) {
        removeMenu()
        floatView?.visibility = View.GONE
        setRunningState(false)
        currentEditKey = key
        hidePreview(key)

        val p = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            format = PixelFormat.TRANSLUCENT
        }

        editorLifecycleOwner = ServiceLifecycleOwner().apply { attach() }

        editorView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            editorLifecycleOwner?.injectInto(this)
            setContent {
                EditorWindowUI(
                    title = "编辑: $title",
                    onCancelClick = { closeEditor(true) },
                    onSaveClick = {
                        saveCurrentRegion()
                        showCustomToast("区域已保存")
                        closeEditor(true)
                    },
                    onEditorViewCreated = { rev ->
                        rev.setScreenSize(screenWidth, screenHeight)
                        val l = sp.getFloat("${key}_l", 0f)
                        val t = sp.getFloat("${key}_t", 0f)
                        val w = sp.getFloat("${key}_w", 0f)
                        val h = sp.getFloat("${key}_h", 0f)
                        rev.initData(l, t, w, h)
                        rev.setOnRegionChangedListener { rl, rt, rw, rh ->
                            tempL = rl; tempT = rt; tempW = rw; tempH = rh
                        }
                    }
                )
            }
        }
        windowManager.addView(editorView, p)
        isEditorAdded = true
    }

    private fun saveCurrentRegion() {
        sp.edit().apply {
            putFloat("${currentEditKey}_l", tempL)
            putFloat("${currentEditKey}_t", tempT)
            putFloat("${currentEditKey}_w", tempW)
            putFloat("${currentEditKey}_h", tempH)
            apply()
        }
        ConfigManager.saveToDisk(this)
        
        
        syncMenuCheckStates()
    }


    private fun closeEditor(openMenu: Boolean) {
        if (editorView != null && isEditorAdded) {
            windowManager.removeView(editorView)
            editorLifecycleOwner?.destroy()
            isEditorAdded = false
            floatView?.visibility = View.VISIBLE
            if (openMenu) showMenu()
        }
    }

    fun setRunningState(running: Boolean) {
        isRunning = running
        if (running) {
            startTime = System.currentTimeMillis()
            remainingMinutes = if (maxRunTimeMillis > 0) maxRunTimeMillis / 60000 else 0
        }
    }
    
    

            private fun performSmartLogic() {
       
        rootInActiveWindow?.refresh()
        
        var handled = false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val windows = windows
            if (windows != null) {
                for (w in windows) {
        
                    w.root?.refresh() 
                    
                    if (processNodeLogic(w.root)) {
                        handled = true
                        break
                    }
                }
            }
        }
        

        if (!handled) {
            handled = processNodeLogic(rootInActiveWindow)
        }

        if (!handled) {
            val sw = sp.getFloat("scan_w", 0f)
            val sh = sp.getFloat("scan_h", 0f)
            if (sw > 0f && sh > 0f) {
                val sl = sp.getFloat("scan_l", 0f)
                val st = sp.getFloat("scan_t", 0f)
                
                val scanRect = Rect(
                    (screenWidth * sl).toInt(),
                    (screenHeight * st).toInt(),
                    (screenWidth * sl).toInt() + (screenWidth * sw).toInt(),
                    (screenHeight * st).toInt() + (screenHeight * sh).toInt()
                )
                
                val targetNode = findNodeByTextAndBounds(rootInActiveWindow, "执行中", scanRect)
                if (targetNode != null) {
                    // 使用和其他按钮一样的智能点击逻辑，支持穿透悬浮窗
                    performSmartClick(targetNode)
                    handled = true // 标记已处理，防止同一次扫描中误点其他按钮
                }
            }
        }
    }

    private fun performSmartClick(node: AccessibilityNodeInfo) {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        // 【修复1防假死】：如果其他按钮原生点击失败，强制回退为坐标手势点击，避免光有冷却时间不点击
        if (!tryClickNode(node)) {
            performGestureClick(rect.centerX().toFloat(), rect.centerY().toFloat())
        } else {
            showTouchEffectAt(rect.centerX().toFloat(), rect.centerY().toFloat())
            val dPost = sp.getInt("d_post", 1800).toLong()
            nextActionTime = System.currentTimeMillis() + dPost
        }
    }



        private fun findNodeByTextAndBounds(node: AccessibilityNodeInfo?, targetText: String, bounds: Rect): AccessibilityNodeInfo? {
        if (node == null) return null
        
        // 【安全锁 1：防误伤】只认目标软件的界面，如果是辅助工具自己或者微信等，直接无视！
        if (node.packageName?.toString() != "com.yixi.whsmartgov") return null
        
        val nodeText = getNodeText(node) ?: ""
        
        // 【安全锁 2：防幽灵节点】加上 node.isVisibleToUser，只认肉眼看得见的文字！
        if (node.isVisibleToUser && nodeText.contains(targetText)) {
            val nodeRect = Rect()
            node.getBoundsInScreen(nodeRect)
            if (Rect.intersects(nodeRect, bounds)) {
                return node
            }
        }
        
        for (i in 0 until node.childCount) {
            val found = findNodeByTextAndBounds(node.getChild(i), targetText, bounds)
            if (found != null) return found
        }
        return null
    }




    private fun processNodeLogic(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        
        // 【新增安全锁】：只要包名不是目标应用，绝对不执行点击
        if (node.packageName?.toString() != "com.yixi.whsmartgov") return false
        
        val text = getNodeText(node) ?: ""
        if (text.contains("返回风险分析单元列表") && checkRect(node, "next")) {
             performSmartClick(node) 
             
             return true
        }
        
        if (checkAndClick(node, "下一个风险分析单元", "next", true) ||
            checkAndClick(node, "未检查", "check", true) ||
            checkAndClick(node, "受控", "ctrl", true)) {
            return true
        }
        
        for (i in 0 until node.childCount) {
            if (processNodeLogic(node.getChild(i))) return true
        }
        return false
    }



    private fun checkAndClick(node: AccessibilityNodeInfo, keyText: String, key: String, partialMatch: Boolean): Boolean {
        if (!node.isVisibleToUser) return false
        
        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (rect.isEmpty || rect.width() <= 0 || rect.height() <= 0) return false

        val text = getNodeText(node) ?: return false
        val match = if (partialMatch) text.contains(keyText) else text == keyText
        if (match) {
            if (checkRect(node, key)) {
                performSmartClick(node)
                return true
            }
        }
        return false
    }

    private fun checkRect(node: AccessibilityNodeInfo, key: String): Boolean {
        val l = sp.getFloat("${key}_l", 0f)
        val t = sp.getFloat("${key}_t", 0f)
        val w = sp.getFloat("${key}_w", 0f)
        val h = sp.getFloat("${key}_h", 0f)
        if (w == 0f || h == 0f) return true
        
        val nodeRect = Rect()
        node.getBoundsInScreen(nodeRect)
        val targetRect = Rect(
            (screenWidth * l).toInt(),
            (screenHeight * t).toInt(),
            (screenWidth * l).toInt() + (screenWidth * w).toInt(),
            (screenHeight * t).toInt() + (screenHeight * h).toInt()
        )
        return Rect.intersects(nodeRect, targetRect)
    }

    private fun getRectByKey(key: String): Rect {
        val l = sp.getFloat("${key}_l", 0f)
        val t = sp.getFloat("${key}_t", 0f)
        val w = sp.getFloat("${key}_w", 0f)
        val h = sp.getFloat("${key}_h", 0f)
        if (w == 0f || h == 0f) return Rect(0, 0, screenWidth, screenHeight)
        return Rect(
            (screenWidth * l).toInt(),
            (screenHeight * t).toInt(),
            (screenWidth * l).toInt() + (screenWidth * w).toInt(),
            (screenHeight * t).toInt() + (screenHeight * h).toInt()
        )
    }

    

    private fun tryClickNode(node: AccessibilityNodeInfo): Boolean {
        var t: AccessibilityNodeInfo? = node
        while (t != null) {
            if (t.isClickable) {
                t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
            t = t.parent
        }
        return false
    }

    private fun performGestureClick(x: Float, y: Float) {
        showTouchEffectAt(x, y)
        
        val dClick = sp.getInt("d_click", 200).toLong()
        val dPost = sp.getInt("d_post", 1800).toLong()
        
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dClick))
            .build()
        
        dispatchGesture(gesture, null, null)
        
        nextActionTime = System.currentTimeMillis() + dClick + dPost
    }

    private fun getNodeText(n: AccessibilityNodeInfo): String? {
        if (n.text != null) return n.text.toString()
        if (n.contentDescription != null) return n.contentDescription.toString()
        return null
    }

    fun showPreview(key: String, l: Float, t: Float, w: Float, h: Float) {
        hidePreview(key)
        if (w == 0f || h == 0f) return
        val v = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FF0000"))
                setStroke(5, Color.RED)
            }
        }
        val lp = WindowManager.LayoutParams().apply {
            width = (screenWidth * w).toInt()
            height = (screenHeight * h).toInt()
            x = (screenWidth * l).toInt()
            y = (screenHeight * t).toInt()
            type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(v, lp)
        previewViews[key] = v
    }

    fun hidePreview(key: String) {
        previewViews[key]?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
            previewViews.remove(key)
        }
    }

    fun setShowTouch(show: Boolean) { this.isShowTouch = show }

    fun setScreenOn(enable: Boolean) {
        this.isScreenOn = enable
        applyScreenOn()
    }

    /** 根据 isScreenOn 申请/释放屏幕长亮 WakeLock */
    private fun applyScreenOn() {
        try {
            if (isScreenOn) {
                if (wakeLock == null) {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wakeLock = pm.newWakeLock(
                        PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "WHSS:screenOn"
                    )
                    wakeLock?.setReferenceCounted(false)
                }
                if (wakeLock?.isHeld != true) {
                    wakeLock?.acquire()
                }
            } else {
                if (wakeLock?.isHeld == true) wakeLock?.release()
                wakeLock = null
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showTouchEffectAt(x: Float, y: Float) {
        if (!isShowTouch) return
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#AA00FF00"))
            }
        }
        val lp = WindowManager.LayoutParams().apply {
            width = 120; height = 120
            this.x = x.toInt() - 60; this.y = y.toInt() - 60
            type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.START
        }
        handler.post {
            try {
                windowManager.addView(dot, lp)
                handler.postDelayed({ try { windowManager.removeView(dot) } catch (e: Exception) {} }, 300)
            } catch (e: Exception) {}
        }
    }

    private fun showCustomToast(msg: String) {
        handler.post { Toast.makeText(this@AutoService, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onUnbind(intent: Intent): Boolean {
        if (isWindowAdded) removeFloatView()
        if (isMenuAdded) removeMenu()
        if (isEditorAdded) closeEditor(false)
        previewViews.values.forEach { try { windowManager.removeView(it) } catch (e: Exception) {} }
        previewViews.clear()
        isRunning = false
        instance = null
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) {}
        wakeLock = null
        handler.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {}
    override fun onInterrupt() {}
}

class ServiceLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store
    fun attach() {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }
    fun injectInto(view: View) {
        view.setViewTreeLifecycleOwner(this)
        view.setViewTreeViewModelStoreOwner(this)
        view.setViewTreeSavedStateRegistryOwner(this)
    }
    fun destroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
