package com.p.p

import android.content.Context
import android.os.Environment
import android.util.Log
import org.json.JSONObject
import java.io.File

object ConfigManager {
    private const val FILE_NAME = "危化预防.json"

    // 参数说明表：保存时把说明写成以 // 开头的注释行，读取时自动忽略
    private val KEY_COMMENTS = mapOf(
        "d_click" to "点击持续时间(ms) - 模拟点击手势的按压时长",
        "d_post" to "动作后等待(ms) - 每次操作完成后到下一步的冷却时间",
        "max_time" to "最大运行时间(分钟) - 自动任务总时长上限，0 表示不限制",
        "show_touch" to "显示模拟触摸白点 - 开启后点击位置显示小白点",
        "screen_on" to "是否开启屏幕长亮 - 开启后屏幕保持常亮不熄灭",
        "scan_l" to "执行中 区域-左边距(屏幕宽比例 0~1)",
        "scan_t" to "执行中 区域-上边距(屏幕高比例 0~1)",
        "scan_w" to "执行中 区域-宽度(屏幕宽比例 0~1)",
        "scan_h" to "执行中 区域-高度(屏幕高比例 0~1)",
        "check_l" to "未检查 区域-左边距(屏幕宽比例 0~1)",
        "check_t" to "未检查 区域-上边距(屏幕高比例 0~1)",
        "check_w" to "未检查 区域-宽度(屏幕宽比例 0~1)",
        "check_h" to "未检查 区域-高度(屏幕高比例 0~1)",
        "ctrl_l" to "受控 区域-左边距(屏幕宽比例 0~1)",
        "ctrl_t" to "受控 区域-上边距(屏幕高比例 0~1)",
        "ctrl_w" to "受控 区域-宽度(屏幕宽比例 0~1)",
        "ctrl_h" to "受控 区域-高度(屏幕高比例 0~1)",
        "next_l" to "下一个 区域-左边距(屏幕宽比例 0~1)",
        "next_t" to "下一个 区域-上边距(屏幕高比例 0~1)",
        "next_w" to "下一个 区域-宽度(屏幕宽比例 0~1)",
        "next_h" to "下一个 区域-高度(屏幕高比例 0~1)",
        "ok_l" to "知道了 区域-左边距(屏幕宽比例 0~1)",
        "ok_t" to "知道了 区域-上边距(屏幕高比例 0~1)",
        "ok_w" to "知道了 区域-宽度(屏幕宽比例 0~1)",
        "ok_h" to "知道了 区域-高度(屏幕高比例 0~1)"
    )

    // 将配置文件保存在公共目录，卸载软件不会被删除
    private fun getConfigFile(): File {
        return File(Environment.getExternalStorageDirectory(), FILE_NAME)
    }

    // 将 SharedPreferences 以「缩进 + 注释」的 JSON 写入本地文件
    fun saveToDisk(context: Context) {
        try {
            val sp = context.getSharedPreferences("auto_config", Context.MODE_PRIVATE)
            val all = sp.all
            val keys = all.keys.sorted()

            val sb = StringBuilder()
            sb.append("// 危化杀手 - 配置文件\n")
            sb.append("// 以 // 开头的行为注释，程序读取时会自动忽略，可放心手动修改数值\n")
            sb.append("{\n")
            keys.forEachIndexed { index, key ->
                KEY_COMMENTS[key]?.let { sb.append("  // ").append(it).append("\n") }
                sb.append("  ").append(JSONObject.quote(key)).append(": ")
                when (val v = all[key]) {
                    is Boolean, is Int, is Long, is Float, is Double -> sb.append(v.toString())
                    is String -> sb.append(JSONObject.quote(v))
                    else -> sb.append(JSONObject.quote(v.toString()))
                }
                if (index != keys.size - 1) sb.append(",")
                sb.append("\n")
            }
            sb.append("}\n")

            getConfigFile().writeText(sb.toString())
            Log.i("WHSS", "配置已保存至: ${getConfigFile().absolutePath}")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 从本地 JSON 文件读取到 SharedPreferences，自动忽略 // 注释行
    fun loadFromDisk(context: Context) {
        try {
            val file = getConfigFile()
            if (!file.exists()) return

            val cleaned = file.readLines()
                .filter { !it.trimStart().startsWith("//") }
                .joinToString("\n")

            val json = JSONObject(cleaned)
            val editor = context.getSharedPreferences("auto_config", Context.MODE_PRIVATE).edit()

            json.keys().forEach { key ->
                val value = json.get(key)
                when (value) {
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is String -> editor.putString(key, value)
                    is Double -> editor.putFloat(key, value.toFloat()) // JSON 解析浮点数默认是 Double
                }
            }
            editor.apply()
            Log.i("WHSS", "配置已从本地加载")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
