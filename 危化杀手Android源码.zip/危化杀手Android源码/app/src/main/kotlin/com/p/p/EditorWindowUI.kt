package com.p.p.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.p.p.RegionEditorView // 引入你旧的自定义 View

@Composable
fun EditorWindowUI(
    title: String,
    onCancelClick: () -> Unit,
    onSaveClick: () -> Unit,
    // 暴露自定义 View 以便绑定事件
    onEditorViewCreated: (RegionEditorView) -> Unit 
) {
    Box(modifier = Modifier.fillMaxSize()) {
        
        // 兼容你原来的自定义 Java View
        AndroidView(
            factory = { context ->
                RegionEditorView(context).apply {
                    onEditorViewCreated(this)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // 控制面板改到屏幕向下 40% 的位置
        Column(modifier = Modifier.fillMaxSize()) {
            // 增加一个占位，把下面的内容往下推到屏幕 40% 的高度
            Spacer(modifier = Modifier.fillMaxHeight(0.2f))
            
            Column(
                modifier = Modifier
                    .padding(horizontal = 15.dp)
                    .background(Color(0xBFFFFFFF), RoundedCornerShape(8.dp))
                    .padding(horizontal = 15.dp, vertical = 10.dp)
            ) {
                Text(
                    text = title,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = Color(0xFF546E7A),
                    fontSize = 12.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = onCancelClick,
                        modifier = Modifier.weight(1f).height(35.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF9A9A)),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("关闭", fontSize = 13.sp)
                    }
                    
                    Spacer(modifier = Modifier.width(10.dp))
                    
                    Button(
                        onClick = onSaveClick,
                        modifier = Modifier.weight(1f).height(35.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("保存", fontSize = 13.sp)
                    }
                }
            }
        }
        }
        }


