package com.p.p.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun FloatWindowUI(
    onCloseClick: () -> Unit,
    onMenuClick: () -> Unit,
    onActionClick: () -> Unit,
    onDrag: (Float, Float) -> Unit,
    actionText: String,
    remainText: String, // 接收从外面传进来的剩余时间
    isRunning: Boolean
) {
    // 记住当前是否处于“最小化”状态
    var isMinimized by remember { mutableStateOf(false) }

    // 监听运行状态：一旦运行并且没被缩放，就启动3秒倒计时去缩放
    LaunchedEffect(isRunning, isMinimized) {
        if (isRunning && !isMinimized) {
            delay(3000)
            isMinimized = true
        }
    }

    // 监听运行状态：一旦用户点击暂停（isRunning变为false），强制展开面板
    LaunchedEffect(isRunning) {
        if (!isRunning) {
            isMinimized = false
        }
    }

    if (isMinimized) {
        // ================= 小圆球形态 =================
        Box(
            modifier = Modifier
                .size(50.dp) // 小圆球尺寸
                .background(Color(0xFF2196F3), CircleShape) // 【已修改】：改为蓝色背景
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDrag(dragAmount.x, dragAmount.y)
                    }
                }
                .clickable { isMinimized = false }, // 点击小圆球立即展开
            contentAlignment = Alignment.Center
        ) {
            // 圆球中心显示剩余时间文字
            Text(remainText, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    } else {
        // ================= 展开形态 =================
        Row(
            modifier = Modifier
                .background(Color(0xBFFFFFFF), RoundedCornerShape(8.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDrag(dragAmount.x, dragAmount.y)
                    }
                }
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onCloseClick, modifier = Modifier.size(30.dp), contentPadding = PaddingValues(0.dp)) {
                Text("×", color = Color(0xFFEF9A9A), fontSize = 18.sp) // 关闭按钮留了一点淡红警示色
            }
            Spacer(modifier = Modifier.width(5.dp))
            TextButton(onClick = onMenuClick, modifier = Modifier.size(30.dp), contentPadding = PaddingValues(0.dp)) {
                Text("⚙", color = Color(0xFF90A4AE), fontSize = 18.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Button(
                onClick = onActionClick,
                modifier = Modifier.width(60.dp).height(35.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2196F3) // 【已修改】：无论开始还是暂停，统统使用蓝色
                ),
                shape = RoundedCornerShape(25.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                // 展开状态下只显示 "开始" 或 "暂停"
                Text(actionText, color = Color.White, fontSize = 13.sp)
            }
        }
    }
}
