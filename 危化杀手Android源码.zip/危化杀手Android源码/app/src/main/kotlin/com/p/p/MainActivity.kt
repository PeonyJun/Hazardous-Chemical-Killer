package com.p.p

import androidx.compose.foundation.text.selection.SelectionContainer
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val kaIntent = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(kaIntent)
            } else {
                startService(kaIntent)
            }
        } catch (e: Exception) {
        }
        window.statusBarColor = android.graphics.Color.parseColor("#F2F5F8")
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = true
        setContent {
            MaterialTheme {
                Surface(color = Color(0xFFF2F5F8), modifier = Modifier.fillMaxSize()) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val sp = context.getSharedPreferences("auto_config", Context.MODE_PRIVATE)

    var refreshTrigger by remember { mutableStateOf(0) }
    
    LaunchedEffect(Unit) {
        ConfigManager.loadFromDisk(context)
        refreshTrigger++
    }

    LaunchedEffect(refreshTrigger) {
        while (true) {
            delay(1000)
            refreshTrigger++
        }
    }

    val hasOverlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)
    val isServiceRunning = AutoService.instance != null
    val isVpnActive = VpnInterceptService.isVpnActive

    val hasStoragePerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    val storagePermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            try {
                context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
            } catch (e: Exception) {}
        }
    }

    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val intent = Intent(context, VpnInterceptService::class.java)
            intent.action = VpnInterceptService.ACTION_START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    var isEditing by remember { mutableStateOf(false) }
    var dClick by remember { mutableStateOf(sp.getInt("d_click", 200).toString()) }
    var dPost by remember { mutableStateOf(sp.getInt("d_post", 1800).toString()) }
    var maxTime by remember { mutableStateOf(sp.getInt("max_time", 60).toString()) }
    var showTouch by remember { mutableStateOf(sp.getBoolean("show_touch", true)) }
    var screenOn by remember { mutableStateOf(sp.getBoolean("screen_on", true)) }

    val saveConfig = {
        sp.edit().apply {
            putInt("d_click", dClick.toIntOrNull() ?: 200)
            putInt("d_post", dPost.toIntOrNull() ?: 1800)
            putInt("max_time", maxTime.toIntOrNull() ?: 60)
            putBoolean("show_touch", showTouch) 
            putBoolean("screen_on", screenOn)
            apply()
        }
        ConfigManager.saveToDisk(context)
        AutoService.instance?.let {
            it.setShowTouch(showTouch)
            it.setScreenOn(screenOn)
            it.updateMaxTime()
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("危化杀手", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF37474F))
        Text("自动化点击辅助工具", fontSize = 14.sp, color = Color(0xFF90A4AE), modifier = Modifier.padding(top = 5.dp, bottom = 20.dp))

        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 20.dp)) {
                    Box(modifier = Modifier.width(4.dp).height(16.dp).background(Color(0xFF64B5F6)).padding(end = 10.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isServiceRunning) "服务运行中" else "服务未连接",
                        fontSize = 16.sp, fontWeight = FontWeight.Bold,
                        color = if (isServiceRunning) Color(0xFF4CAF50) else Color(0xFFAAAAAA)
                    )
                }

                Button(
                    onClick = {
                        if (!hasOverlay || !isServiceRunning) {
                            Toast.makeText(context, "请先授予悬浮窗和无障碍权限", Toast.LENGTH_SHORT).show()
                        } else {
                            AutoService.instance?.toggleWindow()
                            refreshTrigger++
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        // 【已修改】：将粉色替换为统一的护眼绿
                        containerColor = if (hasOverlay && isServiceRunning && AutoService.instance?.isWindowAdded == true) Color(0xFF4CAF50) else Color(0xFF2196F3)
                    )
                ) {
                    Text(if (!hasOverlay || !isServiceRunning) "请先授予所有权限" else if (AutoService.instance?.isWindowAdded == true) "关闭悬浮窗" else "开启悬浮窗")
                }

                
                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        if (isVpnActive) {
                            val stopIntent = Intent(context, VpnInterceptService::class.java)
                            stopIntent.action = VpnInterceptService.ACTION_STOP
                            context.startService(stopIntent)
                        } else {
                            val intent = VpnService.prepare(context)
                            if (intent != null) {
                                vpnLauncher.launch(intent)
                            } else {
                                val startIntent = Intent(context, VpnInterceptService::class.java)
                                startIntent.action = VpnInterceptService.ACTION_START
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    context.startForegroundService(startIntent)
                                } else {
                                    context.startService(startIntent)
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    // 【已修改】：将粉色替换为统一的护眼绿
                    colors = ButtonDefaults.buttonColors(containerColor = if (isVpnActive) Color(0xFF4CAF50) else Color(0xFF2196F3))
                ) {
                    Text(if (isVpnActive) "已开启拦截" else "开启拦截模式")
                }

                
                Spacer(modifier = Modifier.height(10.dp))
                
                OutlinedButton(
                    onClick = {
                        val targetPkg = "com.yixi.whsmartgov"
                        var launchIntent = context.packageManager.getLaunchIntentForPackage(targetPkg)
                        if (launchIntent == null) {
                            launchIntent = Intent(Intent.ACTION_MAIN).apply {
                                addCategory(Intent.CATEGORY_LAUNCHER)
                                setPackage(targetPkg)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                        }
                        try { context.startActivity(launchIntent) } catch (e: Exception) { Toast.makeText(context, "启动失败，请确认是否安装该应用", Toast.LENGTH_SHORT).show() }
                    },
                    modifier = Modifier.fillMaxWidth().height(45.dp)
                ) {
                    Text("启动目标应用")
                }
            }
        }




        
        Text("权限管理", fontSize = 12.sp, color = Color(0xFFB0BEC5), modifier = Modifier.padding(start = 5.dp, bottom = 10.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
            Column {
                Row(modifier = Modifier.fillMaxWidth().clickable {
                    if (!hasOverlay) {
                        try { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) } catch (e: Exception) {}
                    }
                }.padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("悬浮窗权限", color = Color(0xFF546E7A), fontSize = 15.sp)
                    Text(if (hasOverlay) "已开启" else "去设置 >", color = if (hasOverlay) Color(0xFF4CAF50) else Color(0xFFCFD8DC))
                }
                HorizontalDivider(color = Color(0xFFF2F5F8), thickness = 1.dp)
                Row(modifier = Modifier.fillMaxWidth().clickable {
                    if (!isServiceRunning) {
                        try {
                            val svc = ComponentName(context.packageName, "com.p.p.AutoService").flattenToString()
                            val detail = Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
                            detail.putExtra("android.provider.extra.ACCESSIBILITY_SERVICE_COMPONENT_NAME", svc)
                            context.startActivity(detail)
                        } catch (e: Exception) {
                            try { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e2: Exception) {}
                        }
                    }
                }.padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("无障碍服务", color = Color(0xFF546E7A), fontSize = 15.sp)
                    Text(if (isServiceRunning) "已开启" else "去开启 >", color = if (isServiceRunning) Color(0xFF4CAF50) else Color(0xFFCFD8DC))
                }
                HorizontalDivider(color = Color(0xFFF2F5F8), thickness = 1.dp)
                Row(modifier = Modifier.fillMaxWidth().clickable {
                    if (!hasStoragePerm) {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
                            } else {
                                storagePermLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            }
                        } catch (e: Exception) {}
                    }
                }.padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("配置文件备份权限", color = Color(0xFF546E7A), fontSize = 15.sp)
                    Text(if (hasStoragePerm) "已开启" else "去设置 >", color = if (hasStoragePerm) Color(0xFF4CAF50) else Color(0xFFCFD8DC))
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 5.dp, bottom = 10.dp, end = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("参数配置", fontSize = 12.sp, color = Color(0xFFB0BEC5))
            Text(
                text = if (isEditing) "保存" else "编辑",
                fontSize = 13.sp,
                color = if (isEditing) Color(0xFF4CAF50) else Color(0xFF64B5F6),
                modifier = Modifier.clickable {
                    if (isEditing) saveConfig()
                    isEditing = !isEditing
                }.padding(5.dp)
            )
        }
        
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
            Column(modifier = Modifier.padding(20.dp)) {
                ConfigInputRow("点击持续时间 (ms)", dClick, isEditing) { dClick = it }
                ConfigInputRow("动作后等待 (ms)", dPost, isEditing) { dPost = it }
                ConfigInputRow("最大运行时间 (分钟)", maxTime, isEditing) { maxTime = it }
                ConfigSwitchRow("显示模拟触摸白点", showTouch, isEditing) { showTouch = it }
                ConfigSwitchRow("是否开启屏幕长亮", screenOn, isEditing) { screenOn = it }
            }
        }

        // 【全新功能：黑客风实时监控面板】
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 5.dp, bottom = 10.dp, end = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("实时拦截监控", fontSize = 12.sp, color = Color(0xFFB0BEC5))
            // 【新增】：清空按钮
            Text(
                text = "清空",
                fontSize = 13.sp,
                color = Color(0xFF64B5F6),
                modifier = Modifier.clickable {
                    VpnInterceptService.interceptLogs.clear()
                }.padding(5.dp)
            )
        }
        
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), // 极客黑色背景
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 50.dp)
        ) {
            Column(modifier = Modifier.padding(15.dp).fillMaxWidth()) {
                val logs = VpnInterceptService.interceptLogs
                if (logs.isEmpty()) {
                    Text("等待拦截数据...", color = Color(0xFF4CAF50), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                } else {
                    // 【新增】：SelectionContainer 包裹，允许长按复制文本
                    SelectionContainer {
                        Column {
                            // 最新抓到的日志显示在最上面
                            logs.reversed().forEach { log ->
                                // 如果包含 🔥 符号，说明篡改成功，文字变成警示的红色，其他为绿色
                                val color = if (log.contains("🔥")) Color(0xFFFF5252) else Color(0xFF4CAF50)
                                Text(
                                    text = log,
                                    color = color,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace, // 代码专用等宽字体
                                    lineHeight = 16.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    } // 补回：MainScreen 内部 Column 的结束括号
} // 补回：MainScreen 方法的结束括号

@Composable
fun ConfigInputRow(label: String, value: String, isEditing: Boolean, onValueChange: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().height(45.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp, color = Color(0xFF546E7A))
        if (isEditing) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = Color(0xFF37474F), textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                modifier = Modifier.width(60.dp).height(30.dp).background(Color(0xFFF5F7FA), RoundedCornerShape(4.dp)),
                decorationBox = { innerTextField -> Box(contentAlignment = Alignment.Center) { innerTextField() } }
            )
        } else {
            Text(value, fontSize = 13.sp, color = Color(0xFF37474F))
        }
    }
}

@Composable
fun ConfigSwitchRow(label: String, checked: Boolean, isEditing: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().height(45.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp, color = Color(0xFF546E7A))
        if (isEditing) {
            Switch(checked = checked, onCheckedChange = onCheckedChange, modifier = Modifier.height(30.dp))
        } else {
            Text(text = if (checked) "已开启" else "已关闭", fontSize = 13.sp, color = if (checked) Color(0xFF4CAF50) else Color(0xFFB0BEC5))
        }
    }
}

