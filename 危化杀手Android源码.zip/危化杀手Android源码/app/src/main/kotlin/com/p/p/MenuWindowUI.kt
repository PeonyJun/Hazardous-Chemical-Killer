package com.p.p.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MenuWindowUI(
    onCloseClick: () -> Unit,
    scanChecked: Boolean, onScanChange: (Boolean) -> Unit, onScanEdit: () -> Unit,
    checkChecked: Boolean, onCheckChange: (Boolean) -> Unit, onCheckEdit: () -> Unit,
    ctrlChecked: Boolean, onCtrlChange: (Boolean) -> Unit, onCtrlEdit: () -> Unit,
    // 【已删除 okChecked 参数】
    nextChecked: Boolean, onNextChange: (Boolean) -> Unit, onNextEdit: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(230.dp)
            .background(Color(0xF5F7FAFC), RoundedCornerShape(12.dp))
            .padding(15.dp)
    ) {
        
        @Composable
        fun MenuItem(text: String, isChecked: Boolean, onCheckedChange: (Boolean) -> Unit, onEdit: () -> Unit) {
            Row(modifier = Modifier.fillMaxWidth().height(42.dp), verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = isChecked, 
                    onCheckedChange = onCheckedChange,
                    modifier = Modifier.scale(0.8f)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = text, fontSize = 14.sp, color = Color(0xFF455A64), textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                TextButton(onClick = onEdit, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(50.dp, 30.dp)) {
                    Text("编辑", fontSize = 12.sp, color = Color(0xFF2196F3))
                }
            }
        }

        MenuItem("执行中", scanChecked, onScanChange, onScanEdit)
        MenuItem("未检查", checkChecked, onCheckChange, onCheckEdit)
        MenuItem("受控", ctrlChecked, onCtrlChange, onCtrlEdit)
        // 【已删除 知道了 MenuItem】
        MenuItem("下一个", nextChecked, onNextChange, onNextEdit)

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onCloseClick,
            modifier = Modifier.fillMaxWidth().height(35.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350)),
            contentPadding = PaddingValues(0.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("隐藏面板", fontSize = 13.sp, color = Color.White)
        }
    }
}

