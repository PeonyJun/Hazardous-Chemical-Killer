package com.p.p

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.pow
import kotlin.math.sqrt

class RegionEditorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val selection = RectF()
    private val drawSelection = RectF()
    private val backgroundPaint = Paint().apply { color = Color.parseColor("#50000000") }
    private val borderPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val handlePaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
    }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 40f
        isAntiAlias = true
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }

    private var realScreenWidth = 0
    private var realScreenHeight = 0
    private val viewLocation = IntArray(2)

    private var activeMode = 0
    private var lastRawX = 0f
    private var lastRawY = 0f
    private val HANDLE_RADIUS = 40f

    // 使用 fun interface 完美支持 Kotlin 的 Lambda 闭包写法
    fun interface OnRegionChangedListener {
        fun onRegionChanged(l: Float, t: Float, w: Float, h: Float)
    }

    interface OnInteractionListener {
        fun onInteractionStart()
        fun onInteractionEnd()
    }

    private var changeListener: OnRegionChangedListener? = null
    private var interactionListener: OnInteractionListener? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setOnRegionChangedListener(listener: OnRegionChangedListener) {
        this.changeListener = listener
    }

    fun setOnInteractionListener(listener: OnInteractionListener) {
        this.interactionListener = listener
    }

    fun setScreenSize(w: Int, h: Int) {
        this.realScreenWidth = w
        this.realScreenHeight = h
    }

    fun initData(l: Float, t: Float, w: Float, h: Float) {
        post {
            if (realScreenWidth == 0 || realScreenHeight == 0) {
                realScreenWidth = resources.displayMetrics.widthPixels
                realScreenHeight = resources.displayMetrics.heightPixels
            }

            if (w == 0f && h == 0f) {
                val size = Math.min(realScreenWidth, realScreenHeight) * 0.5f
                val cx = realScreenWidth / 2f
                val cy = realScreenHeight / 2f
                selection.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2)
            } else {
                val left = realScreenWidth * l
                val top = realScreenHeight * t
                val width = realScreenWidth * w
                val height = realScreenHeight * h
                selection.set(left, top, left + width, top + height)
            }
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        getLocationOnScreen(viewLocation)

        drawSelection.set(selection)
        drawSelection.offset(-viewLocation[0].toFloat(), -viewLocation[1].toFloat())

        val w = width.toFloat()
        val h = height.toFloat()
        val saveCount = canvas.saveLayer(0f, 0f, w, h, null)

        canvas.drawRect(0f, 0f, w, h, backgroundPaint)

        val clearPaint = Paint().apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        canvas.drawRect(drawSelection, clearPaint)

        canvas.restoreToCount(saveCount)

        canvas.drawRect(drawSelection, borderPaint)

        drawHandle(canvas, drawSelection.left, drawSelection.top)
        drawHandle(canvas, drawSelection.right, drawSelection.top)
        drawHandle(canvas, drawSelection.left, drawSelection.bottom)
        drawHandle(canvas, drawSelection.right, drawSelection.bottom)

        if (realScreenWidth > 0 && realScreenHeight > 0) {
            val info = String.format(
                "X:%.1f%% Y:%.1f%% W:%.1f%% H:%.1f%%",
                (selection.left / realScreenWidth * 100),
                (selection.top / realScreenHeight * 100),
                (selection.width() / realScreenWidth * 100),
                (selection.height() / realScreenHeight * 100)
            )
            canvas.drawText(info, drawSelection.left, drawSelection.top - 30, textPaint)

            changeListener?.onRegionChanged(
                selection.left / realScreenWidth,
                selection.top / realScreenHeight,
                selection.width() / realScreenWidth,
                selection.height() / realScreenHeight
            )
        }
    }

    private fun drawHandle(canvas: Canvas, x: Float, y: Float) {
        canvas.drawCircle(x, y, HANDLE_RADIUS, handlePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rawX = event.rawX
        val rawY = event.rawY

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                interactionListener?.onInteractionStart()
                activeMode = getTouchMode(rawX, rawY)
                lastRawX = rawX
                lastRawY = rawY
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = rawX - lastRawX
                val dy = rawY - lastRawY
                updateSelection(dx, dy)
                lastRawX = rawX
                lastRawY = rawY
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                interactionListener?.onInteractionEnd()
                activeMode = 0
            }
        }
        return true
    }

    private fun getTouchMode(x: Float, y: Float): Int {
        if (dist(x, y, selection.left, selection.top) < HANDLE_RADIUS * 3) return 1
        if (dist(x, y, selection.right, selection.top) < HANDLE_RADIUS * 3) return 2
        if (dist(x, y, selection.left, selection.bottom) < HANDLE_RADIUS * 3) return 3
        if (dist(x, y, selection.right, selection.bottom) < HANDLE_RADIUS * 3) return 4
        if (selection.contains(x, y)) return 5
        return 0
    }

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        return sqrt((x1 - x2).pow(2) + (y1 - y2).pow(2))
    }

    private fun updateSelection(dx: Float, dy: Float) {
        when (activeMode) {
            1 -> { selection.left += dx; selection.top += dy }
            2 -> { selection.right += dx; selection.top += dy }
            3 -> { selection.left += dx; selection.bottom += dy }
            4 -> { selection.right += dx; selection.bottom += dy }
            5 -> selection.offset(dx, dy)
        }
        selection.sort()
    }
}
