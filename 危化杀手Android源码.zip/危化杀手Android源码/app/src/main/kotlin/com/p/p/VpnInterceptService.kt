package com.p.p

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.random.Random

class VpnInterceptService : VpnService() {

    companion object {
        private const val TAG = "VpnIntercept"
        const val ACTION_START = "com.p.p.ACTION_START"
        const val ACTION_STOP = "com.p.p.ACTION_STOP"
        private const val CHANNEL_ID = "vpn_ch"
        private const val NOTIFY_ID = 1

        private const val TARGET_PKG = "com.yixi.whsmartgov"
        private const val VPN_ADDR = "10.0.0.2"
        private const val VPN_MTU = 1500
        private const val PROXY_PORT = 19876
        private const val PROXY_HOST_WHITELIST = "whjg.yjgl.guizhou.gov.cn"

        private const val MATCH = "\"is_ok\":\"0\""
        private const val REPL = "\"is_ok\":\"0\",\"no_controlled_number\":1"

        var isVpnActive by mutableStateOf(false)
        val interceptLogs = mutableStateListOf<String>()

        fun addLog(msg: String) {
            Handler(Looper.getMainLooper()).post {
                val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                if (interceptLogs.size >= 200) interceptLogs.removeAt(0)
                interceptLogs.add("[$time] $msg")
            }
        }
    }

    @Volatile private var running = false
    @Volatile private var ipId = 1
    private val writeLock = Any()
    private val pool = Executors.newCachedThreadPool { r ->
        Thread(r, "WHSS-${r.hashCode()}").apply { isDaemon = true }
    }

    // ===================== Android 10+：本地代理模式 =====================
    private var proxyServer: ServerSocket? = null
    private var proxyThread: Thread? = null

    // ===================== Android 5~9：TUN 全接管模式 =====================
    private var tunPfd: ParcelFileDescriptor? = null
    private var tunIn: FileInputStream? = null
    private var tunOut: FileOutputStream? = null
    private var readerThread: Thread? = null
    private val tcpConns = ConcurrentHashMap<String, TcpConn>()
    private val udpConns = ConcurrentHashMap<String, UdpConn>()

    // 诊断计数（仅 TUN 模式用）
    @Volatile private var ipv6Cnt = 0
    @Volatile private var ipv4Cnt = 0
    @Volatile private var synCnt = 0
    @Volatile private var dnsCnt = 0

    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { t, e -> Log.e(TAG, "Uncaught ${t.name}", e) }
        createNotifChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try { startForeground(NOTIFY_ID, buildNotif()) } catch (e: Exception) { Log.e(TAG, "fg", e) }
        when (intent?.action) {
            ACTION_STOP -> { stopVpn(); stopSelf(); return START_NOT_STICKY }
            ACTION_START -> { startVpn(); return START_STICKY }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        addLog("⚠️ 拦截服务被系统中断")
        stopVpn(); stopSelf(); super.onRevoke()
    }

    override fun onDestroy() { stopVpn(); super.onDestroy() }

    private fun startVpn() {
        if (running) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startProxyMode()
        } else {
            startTunMode()
        }
    }

    private fun stopVpn() {
        if (!running && tunPfd == null && proxyServer == null) return
        running = false
        isVpnActive = false
        addLog("🛑 拦截服务已关闭")

        proxyThread?.interrupt()
        proxyThread = null
        runCatching { proxyServer?.close() }
        proxyServer = null

        tcpConns.values.forEach { runCatching { it.socket?.close() } }
        tcpConns.clear()
        udpConns.values.forEach { runCatching { it.sock.close() } }
        udpConns.clear()

        runCatching { tunIn?.close() }
        runCatching { tunOut?.close() }
        runCatching { tunPfd?.close() }
        tunIn = null; tunOut = null; tunPfd = null
        readerThread = null
    }

    // =====================================================================
    //  策略 A：Android 10+，本地代理 + setHttpProxy（原稳定方案）
    // =====================================================================

    private fun startProxyMode() {
        try {
            proxyServer = ServerSocket(PROXY_PORT, 50, InetAddress.getByName("127.0.0.1"))
        } catch (e: Exception) {
            Log.e(TAG, "proxy bind", e)
            addLog("⚠️ 服务端口被占用，请重启应用")
            return
        }

        try {
            val builder = Builder()
                .setSession("WHSS_Proxy")
                .setMtu(VPN_MTU)
                .addAddress(VPN_ADDR, 32)
                .addRoute(VPN_ADDR, 32)

            try {
                builder.addAllowedApplication(TARGET_PKG)
            } catch (e: Exception) {
                addLog("⚠️ 未检测到目标应用")
                runCatching { proxyServer?.close() }
                proxyServer = null
                return
            }

            builder.setHttpProxy(android.net.ProxyInfo.buildDirectProxy("127.0.0.1", PROXY_PORT))

            tunPfd = builder.establish() ?: return
            running = true
            isVpnActive = true
            addLog("🛡️ 拦截服务已开启")

            proxyThread = Thread({ proxyLoop() }, "ProxyServer").apply {
                isDaemon = true; start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "startProxyMode", e)
            stopVpn()
        }
    }

    private fun proxyLoop() {
        while (running) {
            val client = try { proxyServer?.accept() } catch (e: Exception) { null } ?: continue
            pool.submit { handleClient(client) }
        }
    }

    private fun handleClient(client: Socket) {
        var server: Socket? = null
        try {
            val cin = client.getInputStream()
            val cout = client.getOutputStream()

            val requestLine = readLine(cin) ?: return
            if (requestLine.isEmpty()) return
            val parts = requestLine.split(" ")
            val method = parts.getOrNull(0) ?: ""
            val urlStr = parts.getOrNull(1) ?: ""

            val headers = mutableListOf<String>()
            var host = ""
            var port = 80
            var contentLength = 0
            var chunked = false

            while (true) {
                val line = readLine(cin) ?: break
                if (line.isEmpty()) break
                headers.add(line)
                val lower = line.lowercase()
                if (lower.startsWith("host:")) {
                    val h = line.substring(5).trim()
                    if (h.contains(":")) {
                        host = h.substringBefore(":")
                        port = h.substringAfter(":").toIntOrNull() ?: port
                    } else host = h
                } else if (lower.startsWith("content-length:")) {
                    contentLength = lower.substring(15).trim().toIntOrNull() ?: 0
                } else if (lower.startsWith("transfer-encoding:") && lower.contains("chunked")) {
                    chunked = true
                }
            }

            if (host.isEmpty()) {
                val withoutProto = urlStr.substringAfter("://")
                host = withoutProto.substringBefore("/")
                if (host.contains(":")) {
                    port = host.substringAfter(":").toIntOrNull() ?: 80
                    host = host.substringBefore(":")
                }
            }

            if (method.equals("CONNECT", true)) {
                server = Socket()
                server.connect(InetSocketAddress(host, if (port == 80) 443 else port), 10000)
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                cout.flush()
                val s = server
                pool.submit { pump(cin, s.getOutputStream()) }
                pump(s.getInputStream(), cout)
                return
            }

            var path = urlStr
            if (urlStr.startsWith("http")) {
                val withoutProto = urlStr.substringAfter("://")
                val idx = withoutProto.indexOf("/")
                path = if (idx >= 0) withoutProto.substring(idx) else "/"
            }

            server = Socket()
            protect(server)
            server.connect(InetSocketAddress(host, port), 10000)
            val sout = server.getOutputStream()
            val sin = server.getInputStream()

            sout.write("$method $path HTTP/1.1\r\n".toByteArray())
            for (h in headers) {
                val lower = h.lowercase()
                when {
                    lower.startsWith("accept-encoding:") -> sout.write("Accept-Encoding: identity\r\n".toByteArray())
                    lower.startsWith("proxy-connection:") || lower.startsWith("connection:") -> sout.write("Connection: close\r\n".toByteArray())
                    else -> sout.write("$h\r\n".toByteArray())
                }
            }
            sout.write("\r\n".toByteArray())

            if (contentLength > 0) {
                val body = ByteArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val r = cin.read(body, read, contentLength - read)
                    if (r == -1) break
                    read += r
                }
                sout.write(body)
            } else if (chunked) {
                readChunked(cin, sout)
            }
            sout.flush()

            val respFirst = readLine(sin) ?: return
            val respHeaders = mutableListOf<String>()
            var respLen = -1
            var respChunked = false
            while (true) {
                val line = readLine(sin) ?: break
                if (line.isEmpty()) break
                val lower = line.lowercase()
                if (lower.startsWith("content-length:")) respLen = lower.substring(15).trim().toIntOrNull() ?: -1
                else if (lower.startsWith("transfer-encoding:") && lower.contains("chunked")) respChunked = true
                respHeaders.add(line)
            }

            val baos = ByteArrayOutputStream()
            if (respChunked) {
                readChunked(sin, baos)
            } else if (respLen >= 0) {
                val body = ByteArray(respLen)
                var read = 0
                while (read < respLen) {
                    val r = sin.read(body, read, respLen - read)
                    if (r == -1) break
                    read += r
                }
                baos.write(body)
            } else {
                val buf = ByteArray(8192)
                while (true) {
                    val r = sin.read(buf)
                    if (r == -1) break
                    baos.write(buf, 0, r)
                }
            }

            var bodyBytes = baos.toByteArray()
            val respStr = String(bodyBytes, Charsets.UTF_8)
            val fullUrl = if (urlStr.startsWith("http")) urlStr else "http://$host$urlStr"
            val hostHit = host.contains(PROXY_HOST_WHITELIST)
            if (hostHit && respStr.contains(MATCH)) {
                bodyBytes = respStr.replace(MATCH, REPL).toByteArray(Charsets.UTF_8)
                addLog("🔥 已修改执行中状态")
                addLog("   请求地址：$fullUrl")
            }

            val sb = StringBuilder()
            sb.append(respFirst).append("\r\n")
            for (h in respHeaders) {
                val lower = h.lowercase()
                if (lower.startsWith("content-length:")) continue
                if (lower.startsWith("transfer-encoding:")) continue
                sb.append(h).append("\r\n")
            }
            sb.append("Content-Length: ").append(bodyBytes.size).append("\r\n")
            sb.append("\r\n")
            cout.write(sb.toString().toByteArray())
            cout.write(bodyBytes)
            cout.flush()
        } catch (e: Exception) {
            Log.e(TAG, "handleClient", e)
        } finally {
            runCatching { server?.close() }
            runCatching { client.close() }
        }
    }

    private fun pump(input: InputStream, output: OutputStream) {
        try {
            val buf = ByteArray(8192)
            while (true) {
                val r = input.read(buf)
                if (r == -1) break
                output.write(buf, 0, r)
                output.flush()
            }
        } catch (e: Exception) { }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = input.read()
            if (c == -1) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) break
            if (c == '\r'.code) continue
            sb.append(c.toChar())
        }
        return sb.toString()
    }

    private fun readChunked(input: InputStream, output: OutputStream) {
        while (true) {
            val sizeLine = readLine(input) ?: break
            if (sizeLine.isEmpty()) continue
            val size = sizeLine.trim().split(";")[0].toIntOrNull(16) ?: break
            if (size == 0) { readLine(input); break }
            val data = ByteArray(size)
            var read = 0
            while (read < size) {
                val r = input.read(data, read, size - read)
                if (r == -1) break
                read += r
            }
            output.write(data, 0, read)
            readLine(input)
        }
    }

    // =====================================================================
    //  策略 B：Android 5~9，TUN 全接管 + 用户态 TCP/IP 栈
    // =====================================================================

    private fun startTunMode() {
        try {
            val builder = Builder()
                .setSession("WHSS_Proxy")
                .setMtu(VPN_MTU)
                .addAddress(VPN_ADDR, 32)
                .addDnsServer("8.8.8.8")
                .addDnsServer("114.114.114.114")
                .addRoute("0.0.0.0", 0)

            try {
                builder.addAllowedApplication(TARGET_PKG)
            } catch (e: Exception) {
                addLog("⚠️ 未检测到目标应用")
                return
            }

            try {
                proxyServer = ServerSocket(PROXY_PORT, 50, InetAddress.getByName("127.0.0.1"))
            } catch (e: Exception) {
                Log.e(TAG, "proxy bind", e)
                addLog("⚠️ 服务端口被占用，请重启应用")
                return
            }

            tunPfd = builder.establish() ?: return
            tunIn = FileInputStream(tunPfd!!.fileDescriptor)
            tunOut = FileOutputStream(tunPfd!!.fileDescriptor)
            running = true
            isVpnActive = true
            addLog("🛡️ 拦截服务已开启")

            proxyThread = Thread({ proxyLoop() }, "ProxyServer").apply {
                isDaemon = true; start()
            }
            readerThread = Thread({ tunLoop() }, "TunReader").apply {
                isDaemon = true; start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "startTunMode", e)
            stopVpn()
        }
    }

    private fun tunLoop() {
        val buf = ByteArray(VPN_MTU)
        while (running) {
            val len = try { tunIn!!.read(buf) } catch (e: Exception) { -1 }
            if (len <= 0) { Thread.sleep(5); continue }
            try { handleIp(buf, len) } catch (e: Exception) { Log.e(TAG, "pkt", e) }
        }
    }

    private fun handleIp(b: ByteArray, len: Int) {
        if (len < 20) return
        val ver = (b[0].toInt() and 0xF0) shr 4
        if (ver == 6) {
            ipv6Cnt++
            return
        }
        if (ver != 4) return
        ipv4Cnt++
        if (ipv4Cnt == 1) addLog("✅ 拦截服务已接管流量")
        val ihl = (b[0].toInt() and 0x0F) * 4
        val totalLen = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
        val proto = b[9].toInt() and 0xFF
        val src = b.copyOfRange(12, 16)
        val dst = b.copyOfRange(16, 20)
        when (proto) {
            6 -> handleTcp(b, ihl, src, dst, totalLen)
            17 -> handleUdp(b, ihl, src, dst, totalLen)
        }
    }

    private inner class TcpConn(
        val key: String,
        val srcIp: ByteArray, val srcPort: Int,
        val dstIp: ByteArray, val dstPort: Int,
        theirSeq0: Long
    ) {
        @Volatile var closed = false
        @Volatile var established = false
        var mySeq: Long = Random.nextInt(1, Int.MAX_VALUE).toLong()
        // SYN-ACK 重传必须复用同一初始序号，否则应用会持续丢弃
        val initialMySeq: Long = mySeq
        var theirSeq: Long = (theirSeq0 + 1) and 0xFFFFFFFFL
        var socket: Socket? = null
        var httpUrl: String = ""
        @Volatile var dataSeen = false
        @Volatile var respLogged = false
        @Volatile var proxied = false
        val pending = ByteArrayOutputStream()
    }

    private fun handleTcp(b: ByteArray, ihl: Int, src: ByteArray, dst: ByteArray, totalLen: Int) {
        val srcPort = ((b[ihl].toInt() and 0xFF) shl 8) or (b[ihl + 1].toInt() and 0xFF)
        val dstPort = ((b[ihl + 2].toInt() and 0xFF) shl 8) or (b[ihl + 3].toInt() and 0xFF)
        val seq = readU32(b, ihl + 4)
        val dataOff = ((b[ihl + 12].toInt() and 0xF0) shr 4) * 4
        val flags = b[ihl + 13].toInt() and 0xFF
        val payloadStart = ihl + dataOff
        val payloadLen = totalLen - payloadStart

        val SYN = flags and 0x02 != 0
        val ACK = flags and 0x10 != 0
        val FIN = flags and 0x01 != 0
        val RST = flags and 0x04 != 0

        val key = "${ipStr(dst)}:$dstPort:${ipStr(src)}:$srcPort"
        val conn = tcpConns[key]

        if (SYN && !ACK) {
            synCnt++
            if (conn == null) {
                val c = TcpConn(key, src, srcPort, dst, dstPort, seq)
                tcpConns[key] = c
                sendTcp(c, 0x12, null, c.theirSeq)
                pool.submit { connectUpstream(c) }
            } else {
                // 应用重传 SYN：用同一初始序号重发 SYN-ACK，且不推进 mySeq
                conn.theirSeq = (seq + 1) and 0xFFFFFFFFL
                val retrans = buildTcp(
                    conn.dstIp, conn.srcIp, conn.dstPort, conn.srcPort,
                    conn.initialMySeq, conn.theirSeq, 0x12, null
                )
                writeTun(retrans)
            }
            return
        }

        if (conn == null) {
            sendRst(dst, src, dstPort, srcPort, seq, 0)
            return
        }

        if (RST) { closeConn(conn); return }
        if (FIN) { sendTcp(conn, 0x11, null, (seq + 1) and 0xFFFFFFFFL); closeConn(conn); return }

        if (payloadLen > 0 && ACK) {
            val endSeq = (seq + payloadLen) and 0xFFFFFFFFL
            if (endSeq == conn.theirSeq) {
                sendTcp(conn, 0x10, null, conn.theirSeq)
                return
            }
            if (!conn.dataSeen) {
                conn.dataSeen = true
            }
            conn.theirSeq = endSeq
            val payload = rewriteRequest(conn, b.copyOfRange(payloadStart, payloadStart + payloadLen))
            val sock = conn.socket
            if (sock != null && conn.established) {
                try { sock.getOutputStream().write(payload); sock.getOutputStream().flush() }
                catch (e: Exception) { closeConn(conn); return }
            } else {
                synchronized(conn) { conn.pending.write(payload) }
            }
            sendTcp(conn, 0x10, null, conn.theirSeq)
        }
    }

    private fun connectUpstream(c: TcpConn) {
        try {
            val s = Socket()
            protect(s)
            s.tcpNoDelay = true
            if (c.dstPort == 80) {
                s.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), PROXY_PORT), 8000)
                c.proxied = true
                c.socket = s
                c.established = true
            } else {
                s.connect(InetSocketAddress(InetAddress.getByAddress(c.dstIp), c.dstPort), 8000)
                c.socket = s
                c.established = true
            }
            synchronized(c) {
                if (c.pending.size() > 0) {
                    val p = c.pending.toByteArray()
                    c.pending.reset()
                    try { s.getOutputStream().write(p); s.getOutputStream().flush() } catch (_: Exception) { }
                }
            }
            startDownlink(c)
        } catch (e: Exception) {
            Log.e(TAG, "connect ${ipStr(c.dstIp)}:${c.dstPort} fail", e)
            sendRst(c.dstIp, c.srcIp, c.dstPort, c.srcPort, 0, c.theirSeq)
            tcpConns.remove(c.key)
        }
    }

    private fun startDownlink(c: TcpConn) {
        pool.submit {
            val buf = ByteArray(16384)
            val acc = ByteArrayOutputStream()
            try {
                val ins = c.socket!!.getInputStream()
                while (running && !c.closed) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    if (c.proxied) {
                        var off = 0
                        while (off < n) {
                            val chunk = minOf(1400, n - off)
                            sendTcp(c, 0x18, buf.copyOfRange(off, off + chunk), c.theirSeq)
                            off += chunk
                        }
                        continue
                    }
                    acc.write(buf, 0, n)
                    while (true) {
                        val raw = acc.toByteArray()
                        if (raw.isEmpty()) break
                        val res = tryExtract(c, raw) ?: break
                        val out = res.first
                        val consumed = res.second
                        acc.reset()
                        if (consumed < raw.size) acc.write(raw, consumed, raw.size - consumed)
                        if (out.isNotEmpty()) {
                            var off = 0
                            while (off < out.size) {
                                val chunk = minOf(1400, out.size - off)
                                sendTcp(c, 0x18, out.copyOfRange(off, off + chunk), c.theirSeq)
                                off += chunk
                            }
                        }
                    }
                }
            } catch (e: Exception) { }
            // 冲刷残量（连接收尾时可能还留着半截数据）
            try {
                val raw = acc.toByteArray()
                var off = 0
                while (off < raw.size) {
                    val chunk = minOf(1400, raw.size - off)
                    sendTcp(c, 0x18, raw.copyOfRange(off, off + chunk), c.theirSeq)
                    off += chunk
                }
            } catch (e: Exception) { }
            if (!c.closed) {
                sendTcp(c, 0x11, null, c.theirSeq)
                closeConn(c)
            }
        }
    }

    private fun chunkedTotal(text: String): Int? {
        var idx = text.indexOf("\r\n\r\n")
        if (idx < 0) return null
        idx += 4
        while (idx < text.length) {
            val lineEnd = text.indexOf("\r\n", idx)
            if (lineEnd < 0) return null
            val size = text.substring(idx, lineEnd).substringBefore(';').trim().toIntOrNull(16) ?: return null
            if (size == 0) return lineEnd + 4
            idx = lineEnd + 2 + size + 2
        }
        return null
    }

    /**
     * 从累积数据里切出第一个完整 HTTP 响应。
     * 返回 (要回写的字节, 消耗的原始字节数)；数据不完整返回 null。
     * 非 HTTP（TLS 等）整块原样透传。
     */
    private fun tryExtract(c: TcpConn, raw: ByteArray): Pair<ByteArray, Int>? {
        if (raw.isEmpty()) return null
        if (raw[0].toInt().toChar() != 'H') return raw.copyOf() to raw.size
        val text = String(raw, Charsets.ISO_8859_1)
        if (!text.startsWith("HTTP/")) return raw.copyOf() to raw.size

        val sep = text.indexOf("\r\n\r\n")
        if (sep < 0) return null
        val head = text.substring(0, sep)

        if (head.contains("Transfer-Encoding: chunked", ignoreCase = true)) {
            val total = chunkedTotal(text) ?: return null
            return raw.copyOfRange(0, total) to total
        }

        val lenMatch = Regex("(?i)Content-Length:\\s*(\\d+)").find(head) ?: return null
        val declared = lenMatch.groupValues[1].toIntOrNull() ?: return null
        val bodyStart = sep + 4
        if (raw.size - bodyStart < declared) return null

        val body = text.substring(bodyStart, bodyStart + declared)
        if (!body.contains(MATCH)) {
            val end = bodyStart + declared
            return raw.copyOfRange(0, end) to end
        }

        val newBody = body.replace(MATCH, REPL)
        val newHead = Regex("(?i)Content-Length:\\s*\\d+")
            .replace(head, "Content-Length: ${newBody.toByteArray(Charsets.ISO_8859_1).size}")
        addLog("🔥 已修改执行中状态")
        if (c.httpUrl.isNotEmpty()) addLog("   请求地址：${c.httpUrl}")
        return (newHead + "\r\n\r\n" + newBody).toByteArray(Charsets.ISO_8859_1) to (bodyStart + declared)
    }

    private fun closeConn(c: TcpConn) {
        if (c.closed) return
        c.closed = true
        runCatching { c.socket?.close() }
        tcpConns.remove(c.key)
    }

    private fun sendRst(srcIp: ByteArray, dstIp: ByteArray, sp: Int, dp: Int, seq: Long, ack: Long) {
        writeTun(buildTcp(srcIp, dstIp, sp, dp, seq, ack, 0x14, null))
    }

    private fun sendTcp(c: TcpConn, flags: Int, payload: ByteArray?, ackNum: Long, advance: Boolean = true) {
        val pkt = buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, c.mySeq, ackNum, flags, payload)
        writeTun(pkt)
        if (!advance) return
        var adv = 0L
        if (flags and 0x02 != 0 || flags and 0x01 != 0) adv += 1
        if (payload != null) adv += payload.size
        c.mySeq = (c.mySeq + adv) and 0xFFFFFFFFL
    }

    private fun buildTcp(
        srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int,
        seq: Long, ack: Long, flags: Int, payload: ByteArray?
    ): ByteArray {
        val pl = payload?.size ?: 0
        // 【关键修复】SYN / SYN-ACK 带 MSS 选项，TCP 头 24 字节；否则部分 Android 9 内核会丢弃回包
        val isSyn = (flags and 0x02) != 0
        val tcpHdrLen = if (isSyn) 24 else 20
        val ipHdrLen = 20
        val total = ipHdrLen + tcpHdrLen + pl
        val b = ByteArray(total)
        b[0] = 0x45
        b[1] = 0
        b[2] = ((total shr 8) and 0xFF).toByte()
        b[3] = (total and 0xFF).toByte()
        b[4] = ((ipId shr 8) and 0xFF).toByte()
        b[5] = (ipId and 0xFF).toByte()
        ipId = (ipId + 1) and 0xFFFF
        b[8] = 0x40
        b[9] = 6
        System.arraycopy(srcIp, 0, b, 12, 4)
        System.arraycopy(dstIp, 0, b, 16, 4)

        val t = ipHdrLen
        put16(b, t, srcPort); put16(b, t + 2, dstPort)
        put32(b, t + 4, seq); put32(b, t + 8, ack)
        b[t + 12] = ((if (isSyn) 6 else 5) shl 4).toByte()
        b[t + 13] = flags.toByte()
        put16(b, t + 14, 65535)
        put16(b, t + 16, 0)
        put16(b, t + 18, 0)
        if (isSyn) {
            b[t + 20] = 2
            b[t + 21] = 4
            put16(b, t + 22, 1460)
        }
        if (pl > 0) System.arraycopy(payload!!, 0, b, ipHdrLen + tcpHdrLen, pl)

        put16(b, 10, onesComplement(b, 0, ipHdrLen))
        put16(b, t + 16, pseudoTcpChecksum(srcIp, dstIp, b, t, tcpHdrLen + pl))
        return b
    }

    private inner class UdpConn(val sock: DatagramSocket)

    private fun handleUdp(b: ByteArray, ihl: Int, src: ByteArray, dst: ByteArray, totalLen: Int) {
        val srcPort = ((b[ihl].toInt() and 0xFF) shl 8) or (b[ihl + 1].toInt() and 0xFF)
        val dstPort = ((b[ihl + 2].toInt() and 0xFF) shl 8) or (b[ihl + 3].toInt() and 0xFF)
        val udpLen = ((b[ihl + 4].toInt() and 0xFF) shl 8) or (b[ihl + 5].toInt() and 0xFF)
        val payloadStart = ihl + 8
        val payloadLen = udpLen - 8
        if (payloadLen <= 0) return
        val payload = b.copyOfRange(payloadStart, payloadStart + payloadLen)

        pool.submit {
            try {
                val isDns = dstPort == 53
                if (isDns) {
                    dnsCnt++
                }
                val key = "${ipStr(src)}:$srcPort"
                val conn = udpConns.getOrPut(key) { UdpConn(DatagramSocket().also { protect(it) }) }
                val target = InetSocketAddress(InetAddress.getByAddress(dst), dstPort)
                conn.sock.send(DatagramPacket(payload, payload.size, target))
                val rbuf = ByteArray(4096)
                val rp = DatagramPacket(rbuf, rbuf.size)
                conn.sock.soTimeout = 3000
                conn.sock.receive(rp)
                val respPayload = rbuf.copyOf(rp.length)
                writeTun(buildUdp(dst, src, dstPort, srcPort, respPayload))
            } catch (e: Exception) {
            }
        }
    }

    private fun buildUdp(srcIp: ByteArray, dstIp: ByteArray, sp: Int, dp: Int, payload: ByteArray): ByteArray {
        val udpLen = 8 + payload.size
        val total = 20 + udpLen
        val b = ByteArray(total)
        b[0] = 0x45
        b[2] = ((total shr 8) and 0xFF).toByte()
        b[3] = (total and 0xFF).toByte()
        b[4] = ((ipId shr 8) and 0xFF).toByte()
        b[5] = (ipId and 0xFF).toByte()
        ipId = (ipId + 1) and 0xFFFF
        b[8] = 0x40
        b[9] = 17
        System.arraycopy(srcIp, 0, b, 12, 4)
        System.arraycopy(dstIp, 0, b, 16, 4)
        put16(b, 20, sp); put16(b, 22, dp)
        put16(b, 24, udpLen); put16(b, 26, 0)
        System.arraycopy(payload, 0, b, 28, payload.size)
        put16(b, 10, onesComplement(b, 0, 20))
        return b
    }

    private fun rewriteRequest(c: TcpConn, data: ByteArray): ByteArray {
        if (data.isEmpty()) return data
        val text = String(data, Charsets.ISO_8859_1)
        if (!text.startsWith("GET") && !text.startsWith("POST") &&
            !text.startsWith("PUT") && !text.startsWith("HEAD")) return data
        val headerEnd = text.indexOf("\r\n\r\n")
        if (headerEnd < 0) return data
        val headerPart = text.substring(0, headerEnd)
        val rest = text.substring(headerEnd)
        val lines = headerPart.split("\r\n")
        val requestLine = lines.firstOrNull() ?: return data
        val host = lines.firstOrNull { it.startsWith("Host:", ignoreCase = true) }
            ?.substringAfter(":")?.trim() ?: ""
        val path = requestLine.split(" ").getOrNull(1) ?: ""
        c.httpUrl = "http://$host$path"
        val rebuilt = lines.map { l ->
            when {
                l.startsWith("Accept-Encoding:", ignoreCase = true) -> "Accept-Encoding: identity"
                l.startsWith("Proxy-Connection:", ignoreCase = true) -> "Connection: close"
                else -> l
            }
        }.joinToString("\r\n")
        return (rebuilt + rest).toByteArray(Charsets.ISO_8859_1)
    }

    // rewriteResponse 已由 startDownlink 里的累积式 tryExtract 取代

    private fun writeTun(data: ByteArray) {
        synchronized(writeLock) {
            try { tunOut?.write(data); tunOut?.flush() } catch (e: Exception) { }
        }
    }

    private fun readU32(b: ByteArray, off: Int): Long =
        ((b[off].toLong() and 0xFF) shl 24) or ((b[off + 1].toLong() and 0xFF) shl 16) or
        ((b[off + 2].toLong() and 0xFF) shl 8) or (b[off + 3].toLong() and 0xFF)

    private fun put16(b: ByteArray, off: Int, v: Int) {
        b[off] = ((v shr 8) and 0xFF).toByte()
        b[off + 1] = (v and 0xFF).toByte()
    }

    private fun put32(b: ByteArray, off: Int, v: Long) {
        b[off] = ((v shr 24) and 0xFF).toByte()
        b[off + 1] = ((v shr 16) and 0xFF).toByte()
        b[off + 2] = ((v shr 8) and 0xFF).toByte()
        b[off + 3] = (v and 0xFF).toByte()
    }

    private fun ipStr(b: ByteArray) =
        "${b[0].toInt() and 0xFF}.${b[1].toInt() and 0xFF}.${b[2].toInt() and 0xFF}.${b[3].toInt() and 0xFF}"

    private fun onesComplement(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        var rem = len
        while (rem > 1) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2; rem -= 2
        }
        if (rem > 0) sum += (b[i].toInt() and 0xFF) shl 8
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    private fun pseudoTcpChecksum(src: ByteArray, dst: ByteArray, pkt: ByteArray, tcpOff: Int, tcpLen: Int): Int {
        var sum = 0
        for (i in 0 until 4 step 2) sum += ((src[i].toInt() and 0xFF) shl 8) or (src[i + 1].toInt() and 0xFF)
        for (i in 0 until 4 step 2) sum += ((dst[i].toInt() and 0xFF) shl 8) or (dst[i + 1].toInt() and 0xFF)
        sum += 6
        sum += tcpLen
        var i = tcpOff
        var rem = tcpLen
        while (rem > 1) {
            sum += ((pkt[i].toInt() and 0xFF) shl 8) or (pkt[i + 1].toInt() and 0xFF)
            i += 2; rem -= 2
        }
        if (rem > 0) sum += (pkt[i].toInt() and 0xFF) shl 8
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "拦截服务", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val pi = android.app.PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("危化杀手")
            .setContentText("拦截模式运行中")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }
}
